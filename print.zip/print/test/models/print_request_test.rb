require 'test_helper'

class PrintRequestTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
