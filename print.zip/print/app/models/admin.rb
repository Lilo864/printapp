class Admin < User
end
