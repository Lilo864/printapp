class PrintRequest < ApplicationRecord
	belongs_to :user
	mount_uploader :print_file, PrintFileUploader
  validates :title, presence: true, on: :create
  validates :print_file, presence: true, on: :create

	def status_code
		arr = ['Received', 'Approved', 'In progress', 'Printed', 'In delivery', 'Delivered']
		arr[self.status]
	end

	def email
		User.find(user_id).email
	end
end
