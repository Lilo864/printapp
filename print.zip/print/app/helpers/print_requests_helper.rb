module PrintRequestsHelper
	def pr_status(status)
		arr = ['Received', 'Approved', 'In progress', 'Printed', 'In delivery', 'Delivered']
		arr[status]
	end
end
