$(document).ready(function(){
	initStatusChange();
});

var initStatusChange = function(){
	$('tr td li a').click(function(){
		var $prid =  $(this).attr('data-prid');
		$.ajax({
			url: "/admin/print_requests/" + $prid,
			type: "PUT",
			data:{
					print_request: {
						status: $(this).attr('data-status')
					}
			},
			success: function(){
				$('#pr' + $prid).remove();
			}
		});
	});
}
