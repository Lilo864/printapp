class Admin::DashboardController < Admin::BaseController
	before_action :authenticate_admin!
	def index 
		@prs = PrintRequest.where status: (params[:status].nil? ? 0 : params[:status])
	end

end