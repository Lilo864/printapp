class Admin::BaseController < ApplicationController
	layout 'admin'
end
