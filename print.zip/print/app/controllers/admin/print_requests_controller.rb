class Admin::PrintRequestsController < Admin::BaseController

	def update
		@pr = PrintRequest.find(params[:id])
		@pr.update pr_params
		render :json=>true
	end
	private
	def pr_params
		params.require(:print_request).permit(:title, :status)
	end
end
