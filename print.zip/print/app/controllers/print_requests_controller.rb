class PrintRequestsController < ApplicationController
	before_action :set_pr, only: [:show]
	before_action :authenticate_user!
	def index
		@prs = current_user.print_requests.where status: (params[:status].nil? ? 0 : params[:status])
		@pr = PrintRequest.new
	end

	def new
		@pr = PrintRequest.new
	end

	def create
		@pr = current_user.print_requests.build pr_params

		if @pr.save
			redirect_to print_requests_path
      flash[:success] = "Request successfully created."
		else
			render 'new'
		end
	end

	private

	def set_pr
		@pr = PrintRequest.find(params[:id])
	end

	def pr_params
		params.require(:print_request).permit(:title, :user_id, :print_file)
	end
end
