class UpdateDefaultForStatus < ActiveRecord::Migration[5.0]
  def change
    change_column_default :print_requests, :status, 0
  end
end
