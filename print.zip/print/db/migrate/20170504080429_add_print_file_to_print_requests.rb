class AddPrintFileToPrintRequests < ActiveRecord::Migration[5.0]
  def change
    add_column :print_requests, :print_file, :string
  end
end
